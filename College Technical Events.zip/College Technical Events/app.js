// localStorage helpers (same as earlier)
function getEvents() {
  const raw = localStorage.getItem("tf_events");
  if (!raw) {
    const defaults = [
      {
        id: "e1",
        title: "CodeSprint 2.0",
        category: "coding",
        date: "2026-04-10",
        time: "10:00",
        venue: "CSE Lab 1",
        desc: "3-hour competitive coding contest focusing on DSA.",
        prizes: "Goodies + certificates"
      },
      {
        id: "e2",
        title: "RoboWars Arena",
        category: "robotics",
        date: "2026-04-15",
        time: "11:00",
        venue: "Mechanical Block Ground",
        desc: "Autonomous and manually controlled robots in obstacle arena.",
        prizes: "Cash prizes + trophies"
      },
      {
        id: "e3",
        title: "UI/UX Design Jam",
        category: "design",
        date: "2026-04-18",
        time: "14:00",
        venue: "Seminar Hall A",
        desc: "Rapid design challenge for intuitive interfaces.",
        prizes: "Swag + internship opportunities"
      }
    ];
    localStorage.setItem("tf_events", JSON.stringify(defaults));
    return defaults;
  }
  return JSON.parse(raw);
}

function saveEvents(events) {
  localStorage.setItem("tf_events", JSON.stringify(events));
}

function getRegistrations() {
  const raw = localStorage.getItem("tf_regs");
  return raw ? JSON.parse(raw) : [];
}

function saveRegistrations(regs) {
  localStorage.setItem("tf_regs", JSON.stringify(regs));
}

function categoryBadgeClass(cat) {
  if (cat === "coding") return "badge coding";
  if (cat === "robotics") return "badge robotics";
  if (cat === "design") return "badge design";
  return "badge";
}

// -------- Home highlight --------
function renderHomeEvents() {
  const container = document.getElementById("homeEvents");
  if (!container) return;
  const events = getEvents()
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 3);
  container.innerHTML = "";
  events.forEach((ev) => {
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <div class="card-header">
        <h4>${ev.title}</h4>
        <span class="${categoryBadgeClass(ev.category)}">${ev.category}</span>
      </div>
      <p>${ev.desc}</p>
      <div class="card-footer">
        <span>${ev.date} • ${ev.time}</span>
        <span>${ev.venue}</span>
      </div>
    `;
    container.appendChild(card);
  });
}

// -------- Events with Register buttons --------
function getEvents() {
  const raw = localStorage.getItem("tf_events");
  if (!raw) {
    const defaults = [
      {
        id: "e1",
        title: "CodeSprint 2.0",
        category: "coding",
        date: "2026-04-10",
        time: "10:00",
        venue: "CSE Lab 1",
        desc: "3-hour competitive coding contest focusing on data structures and algorithms.",
        prizes: "Goodies + certificates"
      },
      {
        id: "e2",
        title: "RoboWars Arena",
        category: "robotics",
        date: "2026-04-15",
        time: "11:00",
        venue: "Mechanical Block Ground",
        desc: "Autonomous and manually controlled robots compete in an obstacle arena.",
        prizes: "Cash prizes + trophies"
      },
      {
        id: "e3",
        title: "UI/UX Design Jam",
        category: "design",
        date: "2026-04-18",
        time: "14:00",
        venue: "Seminar Hall A",
        desc: "Rapid design challenge to create intuitive interfaces for real-world problems.",
        prizes: "Swag + internship opportunities"
      },
      {
        id: "e4",
        title: "WebDev Bootcamp",
        category: "coding",
        date: "2026-04-22",
        time: "09:30",
        venue: "IT Block Lab 3",
        desc: "Hands-on workshop on HTML, CSS, and JavaScript for beginners.",
        prizes: "Participation certificates"
      },
      {
        id: "e5",
        title: "BrainStorm Quiz League",
        category: "coding",
        date: "2026-04-25",
        time: "13:00",
        venue: "Auditorium",
        desc: "Technical quiz on CS fundamentals, programming, and latest technologies.",
        prizes: "Medals + goodies"
      },
      {
        id: "e6",
        title: "AI & ML Hackathon",
        category: "coding",
        date: "2026-05-02",
        time: "09:00",
        venue: "Innovation Hub",
        desc: "24-hour hackathon focused on AI/ML problem statements.",
        prizes: "Cash prizes + internship offers"
      }
    ];
    localStorage.setItem("tf_events", JSON.stringify(defaults));
    return defaults;
  }
  return JSON.parse(raw);
}
// -------- Registration page (reuse your old register.html if you want) --------
function populateRegEventDropdown() {
  const select = document.getElementById("regEvent");
  if (!select) return;
  const events = getEvents().slice().sort((a, b) => a.date.localeCompare(b.date));
  const selectedId = localStorage.getItem("tf_selected_event");

  select.innerHTML = `<option value="">Select an event</option>`;
  events.forEach((ev) => {
    const opt = document.createElement("option");
    opt.value = ev.id;
    opt.textContent = `${ev.title} (${ev.date})`;
    if (ev.id === selectedId) opt.selected = true;
    select.appendChild(opt);
  });
}

function handleRegistrationForm() {
  const form = document.getElementById("regForm");
  if (!form) return;
  const msgEl = document.getElementById("regMessage");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("regName").value.trim();
    const roll = document.getElementById("regRoll").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const phone = document.getElementById("regPhone").value.trim();
    const eventId = document.getElementById("regEvent").value;

    if (!eventId) {
      msgEl.textContent = "Please select an event.";
      msgEl.className = "message error";
      return;
    }

    const events = getEvents();
    const ev = events.find((e) => e.id === eventId);
    if (!ev) {
      msgEl.textContent = "Selected event not found.";
      msgEl.className = "message error";
      return;
    }

    const regs = getRegistrations();
    regs.push({
      id: "r" + (regs.length + 1),
      name,
      roll,
      email,
      phone,
      eventId,
      status: "registered"
    });
    saveRegistrations(regs);

    // store basic student profile info for profile page
    localStorage.setItem("tf_student_name", name);
    localStorage.setItem("tf_student_roll", roll);

    msgEl.textContent = "Registration submitted successfully!";
    msgEl.className = "message success";
    form.reset();
    localStorage.removeItem("tf_selected_event");
  });
}// -------- Profile: My Events --------
function renderProfile() {
  const tableBody = document.querySelector("#profileTable tbody");
  if (!tableBody) return;
  const userEmail = localStorage.getItem("userEmail");
  if (!userEmail) {
    tableBody.innerHTML = `<tr><td colspan="3">Please login to view your registrations.</td></tr>`;
    return;
  }

  const regs = getRegistrations().filter((r) => r.email === userEmail);
  const events = getEvents();
  tableBody.innerHTML = "";
  if (!regs.length) {
    tableBody.innerHTML = `<tr><td colspan="3">No registrations found for ${userEmail}.</td></tr>`;
    return;
  }

  regs.forEach((reg) => {
    const ev = events.find((e) => e.id === reg.eventId);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${ev ? ev.title : "-"}</td>
      <td>${ev ? ev.date : "-"}</td>
      <td><span class="status-pill status-${reg.status}">${reg.status}</span></td>
    `;
    tableBody.appendChild(tr);
  });
}

// -------- Admin side (same as before: manage events + registrations) --------
// ... (reuse previous admin event & registration functions) ...

// -------- Search page --------
function renderSearch() {
  const input = document.getElementById("searchInput");
  const results = document.getElementById("searchResults");
  if (!input || !results) return;
  const events = getEvents();

  function draw(term) {
    results.innerHTML = "";
    const filtered = events.filter((e) =>
      e.title.toLowerCase().includes(term.toLowerCase())
    );
    if (!filtered.length) {
      results.innerHTML = "<p>No events found.</p>";
      return;
    }
    filtered.forEach((ev) => {
      const card = document.createElement("article");
      card.className = "card";
      card.innerHTML = `
        <div class="card-header">
          <h4>${ev.title}</h4>
          <span class="${categoryBadgeClass(ev.category)}">${ev.category}</span>
        </div>
        <p>${ev.desc}</p>
        <div class="card-footer">
          <span>${ev.date} • ${ev.time}</span>
          <button class="btn btn-primary" data-register="${ev.id}">Register</button>
        </div>
      `;
      results.appendChild(card);
    });
  }

  input.addEventListener("input", () => draw(input.value));
  results.onclick = (e) => {
    const id = e.target.getAttribute("data-register");
    if (!id) return;
    localStorage.setItem("tf_selected_event", id);
    window.location.href = "register.html";
  };

  draw("");
}

// -------- Bootstrapping --------
document.addEventListener("DOMContentLoaded", () => {
  renderHomeEvents();
  renderEventsList();
  renderUpcoming();
  populateRegEventDropdown();
  handleRegistrationForm();
  renderProfile();
  renderSearch();
  // plus your admin rendering if on admin.html
});