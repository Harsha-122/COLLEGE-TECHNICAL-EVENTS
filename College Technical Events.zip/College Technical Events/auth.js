const ADMIN_EMAIL = "admin@college.edu";
const ADMIN_PASSWORD = "admin123";

function updateNavLinks() {
  const role = localStorage.getItem("role");
  const loginPage = window.location.pathname.endsWith("index.html");

  // Only student pages use profile + nav; admin.html has its own logic if you want.
  const profileIcons = document.querySelectorAll(".profile-icon");
  if (profileIcons.length && !role) {
    // If not logged in and trying to see student pages, you can optionally redirect.
    // requireLogin(); // uncomment if you want hard protection
  }

  // No explicit login link on student pages because login is index.html
}

function requireAdmin() {
  const role = localStorage.getItem("role");
  if (role !== "admin") {
    alert("Admin access only. Please login as admin.");
    window.location.href = "index.html";
  }
}

function requireLogin() {
  const role = localStorage.getItem("role");
  if (!role) {
    alert("Please login first.");
    window.location.href = "index.html";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateNavLinks();

  // Handle tabs on login page
  const studentTabBtn = document.getElementById("studentTabBtn");
  const adminTabBtn = document.getElementById("adminTabBtn");
  const loginRole = document.getElementById("loginRole");
  const loginMessage = document.getElementById("loginMessage");

  if (studentTabBtn && adminTabBtn && loginRole) {
    studentTabBtn.onclick = () => {
      loginRole.value = "student";
      studentTabBtn.className = "btn btn-primary";
      adminTabBtn.className = "btn btn-outline";
      loginMessage.textContent = "Student login selected.";
      loginMessage.className = "message";
    };
    adminTabBtn.onclick = () => {
      loginRole.value = "admin";
      adminTabBtn.className = "btn btn-primary";
      studentTabBtn.className = "btn btn-outline";
      loginMessage.textContent = "Admin login selected (use demo credentials).";
      loginMessage.className = "message";
    };
  }

  // Login form
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      const roleField = document.getElementById("loginRole");
      const roleChoice = roleField ? roleField.value : "student";

      if (!email.includes("@")) {
        loginMessage.textContent = "Please enter a valid email.";
        loginMessage.className = "message error";
        return;
      }
      if (password.length < 6) {
        loginMessage.textContent = "Password must be at least 6 characters.";
        loginMessage.className = "message error";
        return;
      }

      if (roleChoice === "admin") {
        if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
          localStorage.setItem("role", "admin");
          localStorage.setItem("userEmail", email);
          loginMessage.textContent = "Admin login successful. Redirecting...";
          loginMessage.className = "message success";
          setTimeout(() => (window.location.href = "admin.html"), 600);
        } else {
          loginMessage.textContent = "Invalid admin credentials.";
          loginMessage.className = "message error";
        }
      } else {
        // student login – accept any credentials for demo
        localStorage.setItem("role", "student");
        localStorage.setItem("userEmail", email);
        loginMessage.textContent = "Student login successful. Redirecting...";
        loginMessage.className = "message success";
        setTimeout(() => (window.location.href = "home.html"), 600);
      }
    });
  }

  // Protect admin page
  if (window.location.pathname.endsWith("admin.html")) {
    requireAdmin();
  }

  // Profile page tabs
   // Profile page tabs
  const tabProfile = document.getElementById("tabProfile");
  const tabEvents = document.getElementById("tabEvents");
  const tabLogout = document.getElementById("tabLogout");
  const profileSection = document.getElementById("profileSection");
  const myEventsSection = document.getElementById("myEventsSection");

  if (tabProfile && tabEvents && tabLogout) {
    const emailSpan = document.getElementById("profileEmail");
    const nameSpan = document.getElementById("profileName");
    const rollSpan = document.getElementById("profileRoll");

    const email = localStorage.getItem("userEmail") || "Not logged in";
    const name = localStorage.getItem("tf_student_name") || "Not available";
    const roll = localStorage.getItem("tf_student_roll") || "Not available";

    if (emailSpan) emailSpan.textContent = email;
    if (nameSpan) nameSpan.textContent = name;
    if (rollSpan) rollSpan.textContent = roll;

    tabProfile.onclick = () => {
      profileSection.style.display = "block";
      myEventsSection.style.display = "none";
      tabProfile.className = "btn btn-primary";
      tabEvents.className = "btn btn-outline";
    };

    tabEvents.onclick = () => {
      profileSection.style.display = "none";
      myEventsSection.style.display = "block";
      tabEvents.className = "btn btn-primary";
      tabProfile.className = "btn btn-outline";
    };

    tabLogout.onclick = () => {
      localStorage.removeItem("role");
      localStorage.removeItem("userEmail");
      localStorage.removeItem("tf_student_name");
      localStorage.removeItem("tf_student_roll");
      alert("Logged out successfully.");
      window.location.href = "index.html";
    };
  
  }
});